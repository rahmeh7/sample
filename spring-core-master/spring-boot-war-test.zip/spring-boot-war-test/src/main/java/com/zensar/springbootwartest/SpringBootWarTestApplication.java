package com.zensar.springbootwartest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWarTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootWarTestApplication.class, args);
	}

}
