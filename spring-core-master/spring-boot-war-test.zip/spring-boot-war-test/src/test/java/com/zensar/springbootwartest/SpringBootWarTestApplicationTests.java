package com.zensar.springbootwartest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWarTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
