package com.zensar.productmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductManagementWebServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductManagementWebServiceApplication.class, args);
	}

}
